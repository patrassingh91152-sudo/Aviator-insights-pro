
import 'package:flutter/material.dart';
void main()=>runApp(const AviatorApp());
class AviatorApp extends StatelessWidget{
 const AviatorApp({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme: ThemeData.dark(),
   home: const HomePage(),
  );
 }
}
class HomePage extends StatelessWidget{
 const HomePage({super.key});
 @override
 Widget build(BuildContext context){
  return Scaffold(
   appBar: AppBar(title: const Text("Aviator Insights Pro")),
   body: ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Card(child: ListTile(title: Text("VIP Memberships"), subtitle: Text("Daily / Weekly / Monthly"))),
      Card(child: ListTile(title: Text("Google Login + Firebase"), subtitle: Text("Secure access"))),
      Card(child: ListTile(title: Text("Push Notifications"), subtitle: Text("Daily 9AM reminders"))),
      Card(child: ListTile(title: Text("Admin Panel"), subtitle: Text("Hidden premium controls"))),
    ],
   ),
  );
 }
}
