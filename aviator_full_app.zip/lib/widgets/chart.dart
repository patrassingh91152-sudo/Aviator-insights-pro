import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class LiveChart extends StatelessWidget {
  const LiveChart({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 200,
      child: LineChart(
        LineChartData(
          lineBarsData: [
            LineChartBarData(
              spots: const [
                FlSpot(0, 1),
                FlSpot(1, 2),
                FlSpot(2, 1.5),
                FlSpot(3, 3),
                FlSpot(4, 2.5),
              ],
              isCurved: true,
              color: Colors.amber,
            )
          ],
        ),
      ),
    );
  }
}
