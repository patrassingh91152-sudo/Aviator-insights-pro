import 'package:flutter/material.dart';
import '../widgets/chart.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Aviator Dashboard")),
      body: Column(
        children: const [
          SizedBox(height: 20),
          Text("VIP Dashboard", style: TextStyle(fontSize: 20)),
          SizedBox(height: 20),
          LiveChart(),
        ],
      ),
    );
  }
}
