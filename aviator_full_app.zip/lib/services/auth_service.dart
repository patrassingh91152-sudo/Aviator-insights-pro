import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;

  Future<User?> signIn() async {
    final user = await GoogleSignIn().signIn();
    if (user == null) return null;
    final auth = await user.authentication;

    final cred = GoogleAuthProvider.credential(
      accessToken: auth.accessToken,
      idToken: auth.idToken,
    );

    return (await _auth.signInWithCredential(cred)).user;
  }
}
